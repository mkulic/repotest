# Sistemske prakse 2024
Code repo za prakse, ovdje ćeš naći sve što ti treba za rješavanje selekcijskog zadatka
