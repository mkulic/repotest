#!/usr/bin/bash

echo "Creating client Dockerfile"
cd ./client || exit
touch Dockerfile
cat <<EOF >Dockerfile
FROM bitnami/golang

WORKDIR /frontend

COPY client.go .

ENV GO111MODULE=auto

RUN go build -o klijent

EXPOSE 8090

CMD ["./klijent"]
EOF

echo "Client Dockerfile created."

docker build -t frontend-img .
echo "Built frontend-img!"

cd ../server || exit


cat <<EOF >Dockerfile
FROM quay.io/mlrun/python:3.9.13-slim

WORKDIR /backend

COPY . .

RUN pip install -r requirements.txt

EXPOSE 8000

CMD ["uvicorn", "main:app", "--host", "0.0.0.0"]
EOF


echo "Server Dockerfile created."

docker build -t backend-img .
echo "Created backend image!"

echo "Composing containers!"
docker compose up -d
